package play.modules.pusher;

public class BasicUserInfo {

    private String name;

    public BasicUserInfo() {
    }

    public BasicUserInfo(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
